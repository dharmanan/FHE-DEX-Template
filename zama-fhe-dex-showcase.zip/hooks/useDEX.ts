import { useState, useCallback, useEffect } from 'react';
import { ethers } from 'ethers';
import type { UseDEXReturnType, TransactionDetails } from '../types';
import { FhevmService } from '../services/fhevmService';
import { GeminiService } from '../services/geminiService';
import { 
    TOKEN_NAME, 
    TOKEN_SYMBOL, 
    INITIAL_ETH_RESERVE, 
    INITIAL_TOKEN_RESERVE, 
    INITIAL_USER_ETH_BALANCE, 
    INITIAL_USER_TOKEN_BALANCE,
    MOCK_API_DELAY
} from '../constants';

// A fixed private key for a predictable, simulated wallet address.
// This is from hardhat/anvil's default accounts.
const SIMULATED_WALLET_PRIVATE_KEY = '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80';

export const useDEX = (): UseDEXReturnType => {
  // --- LOCAL STATE ---
  const [ethReserve, setEthReserve] = useState(INITIAL_ETH_RESERVE);
  const [tokenReserve, setTokenReserve] = useState(INITIAL_TOKEN_RESERVE);
  const [totalLiquidity, setTotalLiquidity] = useState(Math.sqrt(INITIAL_ETH_RESERVE * INITIAL_TOKEN_RESERVE));
  
  const [userEthBalance, setUserEthBalance] = useState(INITIAL_USER_ETH_BALANCE);
  const [userTokenBalance, setUserTokenBalance] = useState(INITIAL_USER_TOKEN_BALANCE);
  const [userLiquidity, setUserLiquidity] = useState(0);

  const [isLoading, setIsLoading] = useState(false);
  const [isSummaryLoading, setIsSummaryLoading] = useState(false);
  const [isLiveMode, setIsLiveMode] = useState(false);
  const [transactionSummary, setTransactionSummary] = useState<string | null>(null);

  // --- SIMULATED WEB3 STATE ---
  const [userAddress, setUserAddress] = useState<string | null>(null);
  // Create a static wallet instance for the simulation
  const simulatedWallet = new ethers.Wallet(SIMULATED_WALLET_PRIVATE_KEY);

  const fhevmService = new FhevmService(isLiveMode);
  const geminiService = new GeminiService();
  
  // --- MODE CHANGE EFFECT ---
  useEffect(() => {
    if (isLiveMode) {
      // In "Live" mode, show the simulated wallet address and reset to initial balances
      setUserAddress(simulatedWallet.address);
      setUserEthBalance(INITIAL_USER_ETH_BALANCE);
      setUserTokenBalance(INITIAL_USER_TOKEN_BALANCE);
      setUserLiquidity(0);
    } else {
      // In "Dummy" mode, hide the address and reset to initial balances
      setUserAddress(null);
      setUserEthBalance(INITIAL_USER_ETH_BALANCE);
      setUserTokenBalance(INITIAL_USER_TOKEN_BALANCE);
      setUserLiquidity(0);
    }
     setEthReserve(INITIAL_ETH_RESERVE);
     setTokenReserve(INITIAL_TOKEN_RESERVE);
  }, [isLiveMode, simulatedWallet.address]);

  const handleTransaction = useCallback(async (details: TransactionDetails) => {
    setIsLoading(true);
    setIsSummaryLoading(true);
    setTransactionSummary(null);

    const geminiPromise = geminiService.generateTransactionSummary(details);

    try {
      if (isLiveMode) {
        // In live mode, we introduce an artificial delay to simulate a real blockchain transaction.
        await new Promise(resolve => setTimeout(resolve, MOCK_API_DELAY));
      }

      // The core logic is now the same for both Dummy and the new Simulated Live mode.
      const transactionResult = await fhevmService.executeConfidentialTransaction(details);
      if (!transactionResult.success && !isLiveMode) { // FHEVM mock only fails in live mode by design
         throw new Error(transactionResult.error || "Transaction failed");
      }
      
      if (details.type === 'swap') {
          const fee = details.inputAmount * 0.003;
          const inputAmountAfterFee = details.inputAmount - fee;
          if (details.inputAsset === 'ETH') {
              setUserEthBalance(b => b - details.inputAmount);
              setUserTokenBalance(b => b + details.outputAmount);
              setEthReserve(r => r + inputAmountAfterFee);
              setTokenReserve(r => r - details.outputAmount);
          } else {
              setUserTokenBalance(b => b - details.inputAmount);
              setUserEthBalance(b => b + details.outputAmount);
              setTokenReserve(r => r + inputAmountAfterFee);
              setEthReserve(r => r - details.outputAmount);
          }
      } else if (details.type === 'deposit') {
          const lpTokensMinted = (details.inputAmount / ethReserve) * totalLiquidity;
          setUserEthBalance(b => b - details.inputAmount);
          setUserTokenBalance(b => b - details.outputAmount);
          setEthReserve(r => r + details.inputAmount);
          setTokenReserve(r => r + details.outputAmount);
          setUserLiquidity(l => l + lpTokensMinted);
          setTotalLiquidity(t => t + lpTokensMinted);
      } else if (details.type === 'withdraw') {
          const ownershipRatio = details.inputAmount / totalLiquidity;
          const ethWithdrawn = ownershipRatio * ethReserve;
          const tokenWithdrawn = ownershipRatio * tokenReserve;
          
          setUserLiquidity(l => l - details.inputAmount);
          setTotalLiquidity(t => t - details.inputAmount);
          setEthReserve(r => r - ethWithdrawn);
          setTokenReserve(r => r - tokenWithdrawn);
          setUserEthBalance(b => b + ethWithdrawn);
          setUserTokenBalance(b => b + tokenWithdrawn);
      }
      
      const summary = await geminiPromise;
      setTransactionSummary(summary);

    } catch (error) {
        console.error("Transaction Error:", error);
        const errorMessage = error instanceof Error ? error.message : String(error);
        setTransactionSummary(`## Transaction Failed 🚨\n\nUnfortunately, the transaction could not be completed.\n\n**Reason:** ${errorMessage}`);
    } finally {
      setIsLoading(false);
      setIsSummaryLoading(false);
    }
  }, [isLiveMode, ethReserve, tokenReserve, totalLiquidity, fhevmService, geminiService]);

  const swap = useCallback(async (inputAmount: number, inputAsset: 'ETH' | 'TOKEN') => {
    const k = ethReserve * tokenReserve;
    let outputAmount = 0;
    
    if (inputAsset === 'ETH') {
        if (inputAmount > userEthBalance) { alert("Insufficient ETH balance."); return; }
        const fee = inputAmount * 0.003;
        const inputAmountWithFee = inputAmount - fee;
        const newEthReserve = ethReserve + inputAmountWithFee;
        const newTokenReserve = k / newEthReserve;
        outputAmount = tokenReserve - newTokenReserve;

        await handleTransaction({ type: 'swap', inputAsset: 'ETH', inputAmount, outputAsset: TOKEN_SYMBOL, outputAmount });
    } else {
        if (inputAmount > userTokenBalance) { alert(`Insufficient ${TOKEN_SYMBOL} balance.`); return; }
        const fee = inputAmount * 0.003;
        const inputAmountWithFee = inputAmount - fee;
        const newTokenReserve = tokenReserve + inputAmountWithFee;
        const newEthReserve = k / newTokenReserve;
        outputAmount = ethReserve - newEthReserve;

        await handleTransaction({ type: 'swap', inputAsset: TOKEN_SYMBOL, inputAmount, outputAsset: 'ETH', outputAmount });
    }
  }, [handleTransaction, userEthBalance, userTokenBalance, ethReserve, tokenReserve]);

  const deposit = useCallback(async (ethAmount: number) => {
    if (ethAmount > userEthBalance) { alert("Insufficient ETH balance."); return; }
    const tokenAmount = (ethAmount / ethReserve) * tokenReserve;
    if (tokenAmount > userTokenBalance) { alert(`Insufficient ${TOKEN_SYMBOL} balance.`); return; }

    await handleTransaction({ type: 'deposit', inputAsset: 'ETH', inputAmount: ethAmount, outputAsset: TOKEN_SYMBOL, outputAmount: tokenAmount });
  }, [handleTransaction, userEthBalance, userTokenBalance, ethReserve, tokenReserve]);

  const withdraw = useCallback(async (lpAmount: number) => {
    if (lpAmount > userLiquidity) { alert("Insufficient liquidity tokens."); return; }
    const ownershipRatio = lpAmount / totalLiquidity;
    const ethToWithdraw = ownershipRatio * ethReserve;
    const tokenToWithdraw = ownershipRatio * tokenReserve;

    await handleTransaction({ type: 'withdraw', inputAsset: 'LP Tokens', inputAmount: lpAmount, outputAsset: `ETH & ${TOKEN_SYMBOL}`, outputAmount: ethToWithdraw + tokenToWithdraw });
  }, [handleTransaction, userLiquidity, totalLiquidity, ethReserve, tokenReserve]);
  
  const clearTransactionSummary = () => setTransactionSummary(null);

  return {
    ethReserve,
    tokenReserve,
    userEthBalance,
    userTokenBalance,
    userLiquidity,
    totalLiquidity,
    isLoading,
    isSummaryLoading,
    isLiveMode,
    transactionSummary,
    TOKEN_SYMBOL,
    TOKEN_NAME,
    userAddress,
    setIsLiveMode,
    swap,
    deposit,
    withdraw,
    clearTransactionSummary,
  };
};