export const TOKEN_NAME = "Zama";
export const TOKEN_SYMBOL = "ZAMA";

export const INITIAL_ETH_RESERVE = 50;
// FIX: Corrected typo in constant name from INITIAL_TOKEN_RESEREVE to INITIAL_TOKEN_RESERVE.
export const INITIAL_TOKEN_RESERVE = 5000;

export const INITIAL_USER_ETH_BALANCE = 10;
export const INITIAL_USER_TOKEN_BALANCE = 1000;

export const MOCK_API_DELAY = 1500; // ms